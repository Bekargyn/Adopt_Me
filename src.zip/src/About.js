import React from 'react'

const About = () => {
  return (
       <React.Fragment>
    <div>
        <h2> This is About page</h2></div>
        </React.Fragment>
  )
}

export default About